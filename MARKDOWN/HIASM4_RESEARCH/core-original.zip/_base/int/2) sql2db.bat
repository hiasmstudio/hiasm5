del hiasm.db
..\Plug\sqlite3.exe hiasm.db <hiasm.sql